ret=0

# install package onto ROOT
tar zxf /firmware/packages/kitakar5525-packages/iptsd/iptsd-v0.1-2-gbcb2516+0001-finger-multitouch-also-set-ABS_X-and-ABS_Y-ROOT_A.tar.gz -C /system
if [ ! "0" -eq 0 ]; then ret=1; fi

exit 
