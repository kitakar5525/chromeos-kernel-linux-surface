ret=0

# install package onto ROOT
tar zxf /firmware/packages/kitakar5525-packages/iptsd/iptsd-v0.1-1-g141e12d-ROOT_A.tar.gz -C /system
if [ ! "0" -eq 0 ]; then ret=1; fi

exit 
